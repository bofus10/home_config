#!/usr/bin/env bash
node "$(pwd)/out/test/testRunner"
