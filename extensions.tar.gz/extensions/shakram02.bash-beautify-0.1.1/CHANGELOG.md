### [0.0.1]
- Initial release

### [0.0.2~0.0.5]
- Modifying package.json configs

### [0.1.0]
- Editable tab size

### [0.1.1]
- Update tab size property name to avoid conflicts with other extensions